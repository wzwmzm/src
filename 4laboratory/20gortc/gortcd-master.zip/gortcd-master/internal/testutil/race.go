// +build race

package testutil

// Race reports if the race detector is enabled.
const Race = true
