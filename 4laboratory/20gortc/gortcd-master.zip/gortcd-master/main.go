package main

import "gortc.io/gortcd/internal/cli"

func main() {
	cli.Execute()
}
